# Import necessary libraries
import fire
import mlflow
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn import datasets
from sklearn.model_selection import train_test_split

# Define a function to preprocess the wine dataset
def preprocess_data(df: pd.DataFrame):
    # Drop the 'ID' column
    df.drop('ID', axis=1, inplace=True)
        
    # One-hot encode the 'style' column
    df = pd.get_dummies(df, columns=['style'])
    
    # Scale the numeric columns using StandardScaler
    scaler = StandardScaler()
    df.iloc[:, :-3] = scaler.fit_transform(df.iloc[:, :-3])
    
    return df

# Define a function to set up a pipeline with a logistic regression model
def setup_rf_pipeline(scaler):
    # Define a logistic regression model
    rf = LogisticRegression()
    
    # Create a pipeline with the scaler and the model
    pipe = make_pipeline(scaler, rf)
    return pipe

# Define a function to track the performance of a model using MLflow
def track_with_mlflow(model, x_test, y_test, mlflow,model_metadata):

    # Log the model metadata and the accuracy metric to MLflow
    mlflow.log_params(model_metadata)
    mlflow.log_metric("accuracy", model.score(x_test, y_test))
    mlflow.sklearn.log_model(model, "LogisticRegression", registered_model_name="LogReg")

# Define the main function
def main(filename:str,max_k:int ):
    # Load the wine dataset from scikit-learn
    wine = datasets.load_wine()
    wine_x = wine.data
    wine_y = wine.target
    
    # Split the dataset into training and testing sets
    x_train, x_test, y_train, y_test = train_test_split(wine_x, wine_y)
    
    # Define a range of values for a hyperparameter 'k'
    max_k_list=range(1,max_k)
    
    # Loop over the range of values for 'k'
    for k in max_k_list:
        # Start an MLflow run
        with mlflow.start_run():
            # Scale the training and testing sets using StandardScaler
            scaler= StandardScaler()
            x_train=scaler.fit_transform(x_train)
            x_test=scaler.transform(x_test)
        
            # Set up a pipeline with a logistic regression model
            rf = setup_rf_pipeline(scaler)
            
            # Train the model on the training set
            rf.fit(x_train, y_train)
            
            # Store metadata about the model in a dictionary
            model_metadata = {"k": k}
            
            # Track the performance of the model using MLflow
            track_with_mlflow(rf, x_test, y_test, mlflow,model_metadata)
    
if __name__ == "__main__":
    # Parse command-line arguments and call the main function
    fire.Fire(main)
